package com.varsitycollege.accumul8;

//App creators: Mohamed Rajab-ST10116167, Reeselin Pillay-ST10117187,Terell Rangasamy-ST10117009
//

//Code attribution
//Links:https://www.youtube.com/watch?v=SMrB97JuIoM
//      https://www.youtube.com/watch?v=xZZQ5q5pOp0&t=235s

//Authors:Coding in flow
//        tutorialsEU

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


import com.google.firebase.database.DatabaseReference;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;


public class photo extends AppCompatActivity {
    //Variable declaration

    private static final int CAMERA_REQUEST = 1888;
    private static final int MY_CAMERA_PERMISSION_CODE = 100;
    static final int PICK_IMAGE_REQUEST = 1;
    private String mImgRef;
    private StorageReference storeRef;
    private DatabaseReference mDatabaseRef;
    private StorageTask mUploadTask;

    Button addImage;
    ImageView Image;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo);

        //UI components set to variables
        addImage = findViewById(R.id.btnItemInput);
        Image = findViewById(R.id.itemImage);

        storeRef = FirebaseStorage.getInstance().getReference("Items");//the firebase storage folder name


        //if permission is granted to use the camera uses can take their own photos and upload them
        addImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)//checks if the user gives permission to use the phones camera
                {
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, MY_CAMERA_PERMISSION_CODE);//asks for permission to use the camera
                }
                else
                {
                    Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(cameraIntent, CAMERA_REQUEST);
                }

            }
        });



}
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {//for requesting camera permissions
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_CAMERA_PERMISSION_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "camera access granted", Toast.LENGTH_LONG).show();
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
            } else {
                Toast.makeText(this, "camera access denied", Toast.LENGTH_LONG).show();
            }
        }
    }
}

