package com.varsitycollege.accumul8;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;

import java.util.Calendar;
import java.util.HashMap;

public class AddNewItem extends BottomSheetDialogFragment {

    public static final String TAG = "AddNewItem";
    private TextView setCollectionDate;
    private EditText iCategory;
    private EditText iDescription;
    private Button iSave;
    private FirebaseFirestore firestore = FirebaseFirestore.getInstance();
    private DocumentReference addItemRef = firestore.collection("category").document();
    private Context context;
    private String dateCollected = "";
    private TextView tvLoadedItem;
    public static final String KEY_TITLE = "category";
    public static final String KEY_DESCRIPTION ="description";
    public Button Loadbtn;
    private static final int CAMERA_REQUEST = 1888;
    private static final int MY_CAMERA_PERMISSION_CODE = 100;
    static final int PICK_IMAGE_REQUEST = 1;
    private String mImgRef;
    private StorageReference storeRef;
    private DatabaseReference mDatabaseRef;
    private StorageTask mUploadTask;


    ImageView itemPic2;




    public static AddNewItem newInstance(){



        return new AddNewItem();

    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.add_new_item, container, false);

//        itemPic = findViewById(R.id.itemPic);
//
//        storeRef = FirebaseStorage.getInstance().getReference("Items");


    }



    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);



           // }
        //});


        setCollectionDate = view.findViewById(R.id.ItemDate_edittext);
        iCategory = view.findViewById(R.id.ItemCategory_edittext);
        iDescription = view.findViewById(R.id.ItemDescription_edittext);
        iSave = view.findViewById(R.id.Save_button);
       // addImage = view.findViewById(R.id.image_button);


        firestore = FirebaseFirestore.getInstance();


        iCategory.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.toString().equals("")) {
                    iSave.setEnabled(false);
                    iSave.setBackgroundColor(Color.GRAY);
                }else{
                    iSave.setEnabled(true);
                    iSave.setBackgroundColor(getResources().getColor(R.color.green_blue));
                }
            }
            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        iDescription.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.toString().equals("")) {
                    iSave.setEnabled(false);
                    iSave.setBackgroundColor(Color.GRAY);
                }else{
                    iSave.setEnabled(true);
                    iSave.setBackgroundColor(getResources().getColor(R.color.green_blue));
                }
            }
            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        iSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calender = Calendar.getInstance();

                int MONTH = calender.get(Calendar.MONTH);
                int YEAR = calender.get(Calendar.YEAR);
                int DAY = calender.get(Calendar.DATE);

                DatePickerDialog datePickerDialog = new DatePickerDialog(context, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                        month = month+1;
                        iSave.setText(dayOfMonth + "/" + month + "/" + year);
                        dateCollected = dayOfMonth + "/" + month + "/" + year;

                    }
                },YEAR, MONTH, DAY);
                datePickerDialog.show();
            }
        });
        //    https://www.youtube.com/watch?v=oENeg6Ri-VE
//    Introduction to Firebase Database and Services (2020) #androidstudio
//    Oct 13, 2020

        //to add to firebase using hashmap and firestore
        setCollectionDate = view.findViewById(R.id.ItemDate_edittext);
        iCategory = view.findViewById(R.id.ItemCategory_edittext);
        iDescription = view.findViewById(R.id.ItemDescription_edittext);
        iSave = view.findViewById(R.id.Save_button);

        iSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String getCategory = iCategory.getText().toString();
                String getDescription = iDescription.getText().toString();
                String getCollDate = setCollectionDate.getText().toString();

                HashMap<String, Object> hashMap = new HashMap<>();
                hashMap.put("category",getCategory);
                hashMap.put("description", getDescription);
                hashMap.put("date", getCollDate);

                //FirebaseFirestore.getInstance().collection("category")
//                        .document("item data")
//                        .set(hashMap)
                addItemRef.set(hashMap)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Toast.makeText(context, "task saved", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(context, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                            //view button code
                            public void Load_button(View v) {
                                addItemRef.get()
                                        .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                                            @Override
                                            public void onSuccess(DocumentSnapshot documentSnapshot) {
                                                if (documentSnapshot.exists()){
                                                    String category = documentSnapshot.getString(KEY_TITLE);
                                                    String description = documentSnapshot.getString(KEY_DESCRIPTION);
                                                    String date = documentSnapshot.getString(getCollDate);

                                                    tvLoadedItem.setText("Item Name" + category + "\n" +"Item description" + description + "\n\n" +"Date Collected");

                                                }else{
                                                    Toast.makeText(context, "document doesn't exist", Toast.LENGTH_SHORT).show();
                                                }

                                            }
                                        })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(context, "Error!", Toast.LENGTH_SHORT).show();
                                        Log.d(TAG, e.toString());
                                    }
                                });
                            }
                        });
                dismiss();
            }
        });
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }
    @Override
    public void onDismiss(@NonNull DialogInterface dialog) {
        super.onDismiss(dialog);
        Activity activity = getActivity();
        if (activity instanceof OnDialogCloseListner){
            ((OnDialogCloseListner)activity).onDialogClose(dialog);
        }
    }
}



                //adding to firebase using individual class files
          //  }
      //  });
                // }
//}
//        iSave.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                String task = iCategory.getText().toString();
//
//              //  String description = iDescription.getText().toString();
//
//                if (task.isEmpty()) {
//                    Toast.makeText(context, "Empty category not allowed!", Toast.LENGTH_SHORT).show();
//
//                } else {
//
//                    Category category = new Category();
//                    category.setCategory(iCategory.getText().toString());
//
//
//                    firestore.collection("category").add(category).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
//                        @Override
//                        public void onComplete(@NonNull Task<DocumentReference> task) {
//                            if (task.isSuccessful()) {
//                                Toast.makeText(context, "task saved", Toast.LENGTH_SHORT).show();
//                            } else {
//                                Toast.makeText(context, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
//                            }
//                        }
//
//                    }).addOnFailureListener(new OnFailureListener() {
//                        @Override
//                        public void onFailure(@NonNull Exception e) {
//                            Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
//                        }
//
//                    });
//                    String task2 = iDescription.getText().toString();
//                    Description description = new Description();
//                    firestore.collection("description").add(description).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
//                        @Override
//                        public void onComplete(@NonNull Task<DocumentReference> task) {
//
//                        }
//                    });
//
//
//                }

