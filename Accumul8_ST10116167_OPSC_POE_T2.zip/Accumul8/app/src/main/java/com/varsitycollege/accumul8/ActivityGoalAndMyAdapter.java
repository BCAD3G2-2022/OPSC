package com.varsitycollege.accumul8;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;

import java.util.ArrayList;

public class ActivityGoalAndMyAdapter extends AppCompatActivity {


//    How to Select an Image from Gallery in Android?
//    adityamshidlyali
//    https://www.geeksforgeeks.org/how-to-select-an-image-from-gallery-in-android/
//            17 May, 2022


    Button b;
    EditText et;
    TextView tv;

    // private RecyclerView recyclerView;
    private FloatingActionButton fabAdd;
    private Button BtnSetGoal;
    Button btnBack;
    RecyclerView recyclerView;
    ArrayList<Item> itemArrayList;
    MyAdapter myAdapter;
    FirebaseFirestore firestore;
    ProgressDialog progressDialog;


    public Uri imageURI;
    private FirebaseStorage storage;
    private StorageReference storageReference;

    private ImageView itemPic;
    private static final int CAMERA_REQUEST = 1888;
    private static final int MY_CAMERA_PERMISSION_CODE = 100;
    static final int PICK_IMAGE_REQUEST = 1;
    private String mImgRef;
    private StorageReference storeRef;
    private DatabaseReference mDatabaseRef;
    private StorageTask mUploadTask;


    //    https://www.youtube.com/watch?v=CQ5qcJetYAI&list=TLPQMDIwNjIwMjJvIGFw8DD67g&index=1
//    Upload Images to Firebase in Android Studio | Beginner's Guide
//    Apr 20, 2020




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recyclerandgoal);

        itemPic = findViewById(R.id.itemPic);

        storeRef = FirebaseStorage.getInstance().getReference("Items");

        itemPic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)//checks if the user gives permission to use the phones camera
                {
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, MY_CAMERA_PERMISSION_CODE);//asks for permission to use the camera
                }
                else
                {
                    Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(cameraIntent, CAMERA_REQUEST);
                }

            }
        });

        //    https://www.youtube.com/watch?v=Az4gXQAP-a4&list=TLPQMDEwNjIwMjIDs5Dlq7RAfg&index=2
//    Firestore Data to Recyclerview | How to Retrieve Firestore data into Recyclerview | Android Studio
//    May 19, 2021

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Fetching data.......");
        progressDialog.show();

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(ActivityGoalAndMyAdapter.this));


        firestore = FirebaseFirestore.getInstance();
        itemArrayList = new ArrayList<Item>();
        myAdapter = new MyAdapter(ActivityGoalAndMyAdapter.this, itemArrayList);

        recyclerView.setAdapter(myAdapter);

        EventChangeListener();

        //previously created
        recyclerView = findViewById(R.id.recyclerView);
        fabAdd = findViewById(R.id.floatingActionButton);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(ActivityGoalAndMyAdapter.this));
        btnBack = findViewById(R.id.btnBack);

        btnBack.setOnClickListener(new View.OnClickListener() { //this will enable a user to go back to the previous page
            @Override
            public void onClick(View view)
            {
                Intent back = new Intent(ActivityGoalAndMyAdapter.this, CustomCategories.class); //this will take the user to their desired page

                startActivity(back); //will perform the intent
            }
        });

        fabAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AddNewItem.newInstance().show(getSupportFragmentManager(), AddNewItem.TAG);

            }
        });

        BtnSetGoal = (Button) findViewById(R.id.BtnSetGoal2);
        BtnSetGoal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // ViewGoal.setText((CharSequence) SetGoal);
                // createNewBtnSetGoalDialog();
            }
        });

        b = (Button) findViewById(R.id.BtnSetGoal2);
        et = (EditText) findViewById(R.id.setttCollectionGoal);
        tv = (TextView) findViewById(R.id.txtViewGaol);
        //on click listener to get user input and display in text view (collection goal)
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String str = et.getText().toString();
                tv.setText("My Collection Goal Is " + str + " Items");
            }
        });

    }


    private void EventChangeListener() {

        firestore.collection("category")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {

                        if (error!=null){
                            if (progressDialog.isShowing())
                                progressDialog.dismiss();
                            Log.e("Firestore error ",error.getMessage() );
                            return;
                        }
                        for (DocumentChange dc : value.getDocumentChanges()){
                            if (dc.getType()==DocumentChange.Type.ADDED){

                                itemArrayList.add(dc.getDocument().toObject(Item.class));

                            }

                            myAdapter.notifyDataSetChanged();
                            if (progressDialog.isShowing())
                                progressDialog.dismiss();
                        }

                    }
                });
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {//for requesting camera permissions
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_CAMERA_PERMISSION_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "camera access granted", Toast.LENGTH_LONG).show();
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
            } else {
                Toast.makeText(this, "camera access denied", Toast.LENGTH_LONG).show();
            }
        }
    }
}