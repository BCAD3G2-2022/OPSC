package com.varsitycollege.accumul8;

import android.content.DialogInterface;

interface OnDialogCloseListner {

    void onDialogClose(DialogInterface dialogInterface);
}