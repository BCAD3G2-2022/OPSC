package com.varsitycollege.accumul8;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

//App creators: Mohamed Rajab-ST10116167, Reeseslin Pillay-ST10117187,Terell Rangasamy-ST10117009

//Code attribution
//Links: https://www.youtube.com/watch?v=iSsa9OlQJms&t=17s
//       https://stackoverflow.com/questions/41660766/register-account-firebase-through-android-app
//Authors: CodingZest
//         StackOverflow

public class MainActivity extends AppCompatActivity {

    //variable declaration
    Button Login, SignUp;
    EditText email, Password;
    FirebaseAuth Auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //UI components set to variables
        Login = findViewById(R.id.btnLogin);
        SignUp = findViewById(R.id.btnSign);

        email = findViewById(R.id.lEmail);
        Password = findViewById(R.id.lPassword);

        Auth = FirebaseAuth.getInstance();

        Login.setOnClickListener(view -> {
            loginUser();                  //Method is called when button is clicked
        });


        //When the signup button is clicked it will take the user to the signup page
        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, signup.class);
                startActivity(intent);
            }
        });


    }

    private void loginUser() {

        //values from edit boxes are passed to local variables
        String mail = email.getText().toString();
        String Pass = Password.getText().toString();


        if (TextUtils.isEmpty(mail)) {
            email.setError("Email field must not be empty"); //Error handling
            email.requestFocus();
        } else if (TextUtils.isEmpty(Pass)) {
            Password.setError("Password field must not be empty "); //Error handling
            Password.requestFocus();
        } else { //if the fields aren't empty then the nested if statement begins
            Auth.signInWithEmailAndPassword(mail, Pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() { //reads email and password
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    //if statement checks if task is successful or unsuccessful
                    if (task.isSuccessful()) {
                        startActivity(new Intent(MainActivity.this,CategoryPage.class)); //new activity page is opened
                        Toast.makeText(MainActivity.this, "Login successful", Toast.LENGTH_LONG); //message notifying the user is outputted

                    }else{
                        Toast.makeText(MainActivity.this, "Not a registered user. Sign Up?", Toast.LENGTH_SHORT).show(); //message notifying the user is outputted
                    }
                }
            });
        }


    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser user = Auth.getCurrentUser();
        if (user == null) {
            startActivity(new Intent(MainActivity.this, MainActivity.class));
        }
    }
}















