// Terell Rangasamy ST1011700; Reeselin Pillay ST10117187; Mohamed Rajab ST10116167

package com.varsitycollege.accumul8;

public class CustomCategoryClass
{//declaration of variables
     String customCategory;

    public CustomCategoryClass(String customCategory)
    {
        this.customCategory = customCategory;
    }

    public CustomCategoryClass()
    {
//needed for firestore
    }

    //getters and setters
    public String getCustomCategory() {
        return customCategory;
    }

    public void setCustomCategory(String customCategory) {
        this.customCategory = customCategory;
    }
}






