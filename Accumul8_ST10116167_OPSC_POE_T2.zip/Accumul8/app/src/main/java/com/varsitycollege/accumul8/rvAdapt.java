package com.varsitycollege.accumul8;

//Terell Rangasamy ST1011700; Reeselin Pillay ST10117187; Mohamed Rajab ST10116167

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

//Code Attribution
//Link : https://www.youtube.com/watch?v=lAGI6jGS4vs&list=PLrnPJCHvNZuAXdWxOzsN5rgG2M4uJ8bH1&index=3
//Author : Coding in Flow
//End
//FirebaseFirestore adapter

public class rvAdapt extends FirestoreRecyclerAdapter<CustomCategoryClass, rvAdapt.rvViewHolder> {

    public rvAdapt(@NonNull FirestoreRecyclerOptions<CustomCategoryClass> options)
    {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull rvViewHolder rvHolder, int position, @NonNull CustomCategoryClass model)
    {
        rvHolder.tvCustomCategory.setText(model.getCustomCategory()); //this will set the tvCustomCategory according to the input received from the user
    }

    @NonNull
    @Override
    public rvViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View lay = LayoutInflater.from(parent.getContext()).inflate(R.layout.rv_custom_category_create,parent,false); //this will enable the rv_custom_category_create layout to be used
       //
        return  new rvViewHolder(lay); //this will return the layout view
    }

    class rvViewHolder extends RecyclerView.ViewHolder
    {
        //Variable
        TextView tvCustomCategory;

        public rvViewHolder(View item)
        {
            super(item);
            tvCustomCategory = item.findViewById(R.id.tvCustomCategory);

            item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    item.getContext().startActivity(new Intent(item.getContext(), ActivityGoalAndMyAdapter.class)); //Will take the user to the specific Activity
                }
            });
        }
    }
}
