// Terell Rangasamy ST1011700; Reeselin Pillay ST10117187; Mohamed Rajab ST10116167

package com.varsitycollege.accumul8;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class CategoryDetails extends AppCompatActivity {
    //declaration of variables
    TextView tvCustomCategory;
    Button btnAddNewCategory;
    EditText etCategory;
    Button btnBack;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_details);

        db = FirebaseFirestore.getInstance(); //this will get an instance of FirebaseFirestore

//      to link the id and the variable
        tvCustomCategory = findViewById(R.id.tvCustomCategory);
        btnAddNewCategory = findViewById(R.id.btnAddNewCategory);
        etCategory =findViewById(R.id.etCategory);

        btnAddNewCategory.setOnClickListener(new View.OnClickListener() { //this button will take the user back to the previous
            @Override
            public void onClick(View view)
            {
                String customCategory = etCategory.getText().toString();
//Code Attribution
                //Link : https://www.youtube.com/watch?v=1YMK2SatG8o&list=PLrnPJCHvNZuAXdWxOzsN5rgG2M4uJ8bH1&index=6
                //Author : Coding in Flow
                //End
                //Used to link the FirebaseFirestore and the Recyclerview
                CollectionReference catRef = FirebaseFirestore.getInstance().collection("Accumul8"); //this will link the collection reference with the FirebaseFirestore
                catRef.add(new CustomCategoryClass(customCategory)); //This will enable the application to add the custom categories to FirebaseFirestore

                if(etCategory.getText().toString() == "") //if statement to check if the user has entered correctly
                {
                    Toast.makeText(CategoryDetails.this, "Failure", Toast.LENGTH_SHORT).show(); //This will display when the user has not entered their custom category
                }
                else
                {
                    Toast.makeText(CategoryDetails.this, "Success", Toast.LENGTH_SHORT).show(); //This will display when the user has entered their custom category
                    Intent customCategories = new Intent(CategoryDetails.this, CustomCategories.class); // this will take the user to the CustomCategories page where all the new categories will be displayed

                    startActivity(customCategories); //will perform the intent
                }
            }
        });

        btnBack = findViewById(R.id.btnBack); //this links the back button to it id

        btnBack.setOnClickListener(new View.OnClickListener() { //this will enable a user to go back to the previous page
            @Override
            public void onClick(View view)
            {
                Intent back = new Intent(CategoryDetails.this, CustomCategories.class); //this will take the user to their desired page

                startActivity(back); //will perform the intent
            }
        });
    }
}