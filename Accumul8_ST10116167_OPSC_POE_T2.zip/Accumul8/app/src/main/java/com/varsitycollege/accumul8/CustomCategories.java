package com.varsitycollege.accumul8;

//Terell Rangasamy ST1011700; Reeselin Pillay ST10117187; Mohamed Rajab ST10116167

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

public class CustomCategories extends AppCompatActivity {
    //declaration of variables
    ImageView ivLogo;
    TextView tvCustomCategory;
    RecyclerView rvCustomCategory;
    Button btnAddNewCategory;
    rvAdapt rvAdapter;
    Button btnBack;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_categories);

        //to link the id and the variable
        ivLogo = findViewById(R.id.ivLogo);
        rvCustomCategory = findViewById(R.id.rvCustomCategory);
        tvCustomCategory = findViewById(R.id.tvCustomCategory);
        btnAddNewCategory = findViewById(R.id.btnAddNewCategory);

        rvCustomCategory.setHasFixedSize(true); //content won't change size of layout
        rvCustomCategory.setLayoutManager(new LinearLayoutManager(this));

        //Code Attribution
        //Link : https://www.youtube.com/watch?v=cBwaJYocb9I
        //Author : TVAC Studio
        //End
        //Used to link the FirebaseFirestore and the Recyclerview

        db = FirebaseFirestore.getInstance(); //Creates an instance of FirebaseFirestore
        CollectionReference catRef = db.collection("Accumul8"); //links the collection reference with instance

        Query query = catRef.orderBy("customCategory", Query.Direction.DESCENDING); //This will order the custom category in descending order

        FirestoreRecyclerOptions<CustomCategoryClass> options = new FirestoreRecyclerOptions.Builder<CustomCategoryClass>()
                .setQuery(query, CustomCategoryClass.class)
                .build();

        rvAdapter = new rvAdapt(options);
        rvCustomCategory.setAdapter(rvAdapter); //implements the adapter and the specific list



        btnAddNewCategory.setOnClickListener(new View.OnClickListener() { //will take the user to a page where their can enter custom category details
            @Override
            public void onClick(View view)
            {
                Intent newCustom = new Intent(CustomCategories.this,CategoryDetails.class); //this will take the user to their desired page

                startActivity(newCustom); //This will perform the intent
            }
        });

        btnBack = findViewById(R.id.btnBack); //to link the id and the variable

        btnBack.setOnClickListener(new View.OnClickListener() { //this button will take the user back to the previous
            @Override
            public void onClick(View view)
            {
                Intent back = new Intent(CustomCategories.this, CategoryPage.class); //this will take the user to their desired page

                startActivity(back); //this will perform the intent
            }
        });
    }

    @Override
    protected void onStart() //will enable the the adapter to start listening
    {
        super.onStart();
        rvAdapter.startListening();
    }

    @Override
    protected void onStop() //will stop the adapter from listening
    {
        super.onStop();
        rvAdapter.stopListening();
    }
}