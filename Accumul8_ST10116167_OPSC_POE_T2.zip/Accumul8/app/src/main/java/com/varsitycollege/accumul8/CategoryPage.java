// Terell Rangasamy ST1011700; Reeselin Pillay ST10117187; Mohamed Rajab ST10116167

package com.varsitycollege.accumul8;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class CategoryPage extends AppCompatActivity implements View.OnClickListener
{
    //declaration of variables
    ImageView ivLogo;
//    Button btnBooks;
//    Button btnMovies;
//    Button btnArt;
//    Button btnActionFigures;
    Button btnCustomCategory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_page);
//to link the id and the variable
        ivLogo = findViewById(R.id.ivLogo);
//        btnBooks = findViewById(R.id.btnBooks);
//        btnMovies = findViewById(R.id.btnMovies);
//        btnArt = findViewById(R.id.btnArt);
//        btnActionFigures = findViewById(R.id.btnActionFigures);
        btnCustomCategory = findViewById(R.id.btnCustomCategory);

//        btnBooks.setOnClickListener(this);
//        btnMovies.setOnClickListener(this);
//        btnArt.setOnClickListener(this);
//        btnActionFigures.setOnClickListener(this);
        btnCustomCategory.setOnClickListener(this);
    }

    @Override
    public void onClick(View view)
    {
        switch (view.getId()) //switch case statement that will help the app differentiate between buttons and perform actions accordingly
        {
//            case R.id.btnBooks:
//
//                Intent books = new Intent(CategoryPage.this, ActivityGoalAndMyAdapter.class); //this will take the user to their desired page
//
//                startActivity(books); //will perform the intent
//
//                break;
//
//            case R.id.btnMovies:
//
//              //  Intent movies = new Intent(CategoryPage.this,MoviesDetails.class); //this will take the user to their desired page
//
//              //  startActivity(movies); //will perform the intent
//
//                break;
//
//            case R.id.btnArt:
//
//            //    Intent art = new Intent(CategoryPage.this,ArtDetails.class); //this will take the user to their desired page
//
//             //   startActivity(art); //will perform the intent
//
//                break;
//
//            case R.id.btnActionFigures:
//
//             //   Intent af = new Intent(CategoryPage.this,ActionFigureDetails.class); //this will take the user to their desired page
//
//               // startActivity(af); //will perform the intent
//
//                break;

            case R.id.btnCustomCategory:

                Intent customCategory = new Intent(CategoryPage.this,CustomCategories.class); //this will take the user to their desired page

                startActivity(customCategory); //will perform the intent

                break;
        }
    }
}